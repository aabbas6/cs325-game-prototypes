<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tagger" tilewidth="48" tileheight="48" tilecount="1" columns="1">
 <image source="../assets/tagger.png" width="48" height="48"/>
</tileset>
